
# 🔄 Diagrama de Flujo: Sistema de Reset de Usuarios

## 📊 Flujo Principal

```
┌─────────────────────────────────────────────────────────────┐
│                    INICIO DEL PROCESO                        │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  Usuario accede al Panel de Administración                  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │ ¿Es Admin?      │
                    └─────────────────┘
                       │           │
                    SÍ │           │ NO
                       │           │
                       │           ▼
                       │    ┌──────────────────┐
                       │    │ Acceso Denegado  │
                       │    │ Redirect a Home  │
                       │    └──────────────────┘
                       │           │
                       │           ▼
                       │        [FIN]
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  Panel Admin carga con Zona de Peligro visible              │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  Usuario hace clic en "Reiniciar Todos los Usuarios"        │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  Se abre Modal de Confirmación                              │
│  - Icono de advertencia                                     │
│  - Lista de advertencias                                    │
│  - Campo de confirmación                                    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │ Usuario lee     │
                    │ advertencias    │
                    └─────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │ ¿Desea          │
                    │ continuar?      │
                    └─────────────────┘
                       │           │
                    SÍ │           │ NO
                       │           │
                       │           ▼
                       │    ┌──────────────────┐
                       │    │ Clic en Cancelar │
                       │    │ Cierra modal     │
                       │    └──────────────────┘
                       │           │
                       │           ▼
                       │        [FIN]
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  Usuario escribe en campo de confirmación                   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │ Texto ==        │
                    │ "RESETEAR"?     │
                    └─────────────────┘
                       │           │
                    SÍ │           │ NO
                       │           │
                       │           ▼
                       │    ┌──────────────────┐
                       │    │ Botón Confirmar  │
                       │    │ permanece        │
                       │    │ deshabilitado    │
                       │    └──────────────────┘
                       │           │
                       │           ▼
                       │    [Espera input]
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  Botón "Confirmar Reset" se habilita                        │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  Usuario hace clic en "Confirmar Reset"                     │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  Estado: resetting = true                                   │
│  Muestra ActivityIndicator                                  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  Llama a supabase.rpc('admin_reset_all_users')              │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │ Función SQL     │
                    │ ejecuta         │
                    └─────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │ ¿Éxito?         │
                    └─────────────────┘
                       │           │
                    SÍ │           │ NO
                       │           │
                       │           ▼
                       │    ┌──────────────────┐
                       │    │ Muestra Alert    │
                       │    │ con error        │
                       │    └──────────────────┘
                       │           │
                       │           ▼
                       │    ┌──────────────────┐
                       │    │ resetting=false  │
                       │    │ Modal abierto    │
                       │    └──────────────────┘
                       │           │
                       │           ▼
                       │    [Usuario puede     
                       │     reintentar]
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  Muestra Alert de Éxito                                     │
│  "✅ Sistema reiniciado exitosamente. X usuarios            │
│   reseteados a 0."                                          │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  Usuario hace clic en "OK"                                  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  - Cierra modal                                             │
│  - Limpia confirmationText                                  │
│  - Llama a loadStats()                                      │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  Panel Admin se actualiza con nuevas estadísticas           │
│  - Total Usuarios: X                                        │
│  - Total MXI: 0                                             │
│  - Total USDT: 0                                            │
│  - Activos: 0                                               │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      FIN DEL PROCESO                         │
│                   Sistema listo para preventa                │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔧 Flujo de la Función SQL

```
┌─────────────────────────────────────────────────────────────┐
│  admin_reset_all_users(p_admin_id UUID)                     │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  PASO 1: Verificar Permisos                                 │
│  SELECT EXISTS FROM admin_users WHERE user_id = p_admin_id  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │ ¿Es Admin?      │
                    └─────────────────┘
                       │           │
                    SÍ │           │ NO
                       │           │
                       │           ▼
                       │    ┌──────────────────┐
                       │    │ RETURN           │
                       │    │ success: false   │
                       │    │ error: "No       │
                       │    │ permisos"        │
                       │    └──────────────────┘
                       │           │
                       │           ▼
                       │        [FIN]
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  PASO 2: Contar Usuarios                                    │
│  SELECT COUNT(*) INTO v_users_count FROM users              │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  PASO 3: Resetear Usuarios                                  │
│  UPDATE users SET                                           │
│    mxi_balance = 0,                                         │
│    usdt_contributed = 0,                                    │
│    mxi_purchased_directly = 0,                              │
│    mxi_from_unified_commissions = 0,                        │
│    mxi_from_challenges = 0,                                 │
│    mxi_vesting_locked = 0,                                  │
│    active_referrals = 0,                                    │
│    is_active_contributor = false,                           │
│    can_withdraw = false,                                    │
│    yield_rate_per_minute = 0,                               │
│    accumulated_yield = 0                                    │
│  WHERE id != p_admin_id                                     │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  PASO 4: Limpiar Tablas                                     │
│  DELETE FROM commissions                                    │
│  DELETE FROM referrals                                      │
│  DELETE FROM contributions                                  │
│  DELETE FROM withdrawals                                    │
│  DELETE FROM challenge_history                              │
│  DELETE FROM lottery_tickets                                │
│  DELETE FROM game_participants                              │
│  DELETE FROM game_results                                   │
│  DELETE FROM game_sessions                                  │
│  DELETE FROM nowpayments_orders                             │
│  DELETE FROM mxi_withdrawal_schedule                        │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  PASO 5: Resetear Métricas                                  │
│  UPDATE metrics SET                                         │
│    total_members = 56527,                                   │
│    total_usdt_contributed = 0,                              │
│    total_mxi_distributed = 0,                               │
│    total_tokens_sold = 0,                                   │
│    current_phase = 1,                                       │
│    current_price_usdt = 0.30,                               │
│    phase_1_tokens_sold = 0,                                 │
│    phase_2_tokens_sold = 0,                                 │
│    phase_3_tokens_sold = 0                                  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  PASO 6: Retornar Resultado                                 │
│  RETURN jsonb_build_object(                                 │
│    'success', true,                                         │
│    'message', '✅ Sistema reiniciado...',                   │
│    'users_reset', v_users_count                             │
│  )                                                          │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────────────┐
                    │ ¿Error?         │
                    └─────────────────┘
                       │           │
                    NO │           │ SÍ
                       │           │
                       │           ▼
                       │    ┌──────────────────┐
                       │    │ EXCEPTION        │
                       │    │ ROLLBACK         │
                       │    │ RETURN error     │
                       │    └──────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  Resultado exitoso retornado al cliente                     │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎨 Flujo de UI/UX

```
┌─────────────────────────────────────────────────────────────┐
│                    EXPERIENCIA VISUAL                        │
└─────────────────────────────────────────────────────────────┘

ESTADO 1: Panel Admin Normal
┌────────────────────────────────────┐
│ Panel de Administración            │
│ Bienvenido, Admin                  │
├────────────────────────────────────┤
│ [Universal MXI Counter]            │
├────────────────────────────────────┤
│ ⚠️ ZONA DE PELIGRO                 │
│ Reinicia todos los contadores...   │
│ [🔄 Reiniciar Todos los Usuarios]  │ ← BOTÓN ROJO
├────────────────────────────────────┤
│ Métricas de Preventa               │
│ ...                                │
└────────────────────────────────────┘
                │
                │ CLIC
                ▼

ESTADO 2: Modal de Confirmación
┌────────────────────────────────────┐
│ [OVERLAY OSCURO 80%]               │
│                                    │
│  ┌──────────────────────────────┐ │
│  │     ⚠️ [ICONO GRANDE]        │ │
│  │                              │ │
│  │ ¿Reiniciar Todos los         │ │
│  │ Usuarios?                    │ │
│  │                              │ │
│  │ Esta acción es IRREVERSIBLE  │ │
│  │                              │ │
│  │ • Saldos MXI → 0             │ │
│  │ • Comisiones eliminadas      │ │
│  │ • Referidos eliminados       │ │
│  │ • ...                        │ │
│  │                              │ │
│  │ Escribe "RESETEAR":          │ │
│  │ [________________]           │ │ ← INPUT
│  │                              │ │
│  │ [Cancelar] [Confirmar Reset] │ │
│  │             ↑ DESHABILITADO  │ │
│  └──────────────────────────────┘ │
└────────────────────────────────────┘
                │
                │ ESCRIBE "RESETEAR"
                ▼

ESTADO 3: Botón Habilitado
┌────────────────────────────────────┐
│  ┌──────────────────────────────┐ │
│  │ Escribe "RESETEAR":          │ │
│  │ [___RESETEAR____]            │ │ ← TEXTO CORRECTO
│  │                              │ │
│  │ [Cancelar] [Confirmar Reset] │ │
│  │             ↑ HABILITADO     │ │ ← BOTÓN ROJO ACTIVO
│  └──────────────────────────────┘ │
└────────────────────────────────────┘
                │
                │ CLIC EN CONFIRMAR
                ▼

ESTADO 4: Procesando
┌────────────────────────────────────┐
│  ┌──────────────────────────────┐ │
│  │                              │ │
│  │ [Cancelar] [⏳ Loading...]   │ │ ← SPINNER
│  │             ↑ DESHABILITADO  │ │
│  └──────────────────────────────┘ │
└────────────────────────────────────┘
                │
                │ ESPERA 2-5 SEG
                ▼

ESTADO 5: Éxito
┌────────────────────────────────────┐
│ [ALERT NATIVO]                     │
│                                    │
│  ✅ Sistema Reiniciado             │
│                                    │
│  Sistema reiniciado exitosamente.  │
│  7 usuarios reseteados a 0.        │
│                                    │
│           [OK]                     │
└────────────────────────────────────┘
                │
                │ CLIC EN OK
                ▼

ESTADO 6: Panel Actualizado
┌────────────────────────────────────┐
│ Panel de Administración            │
│ Bienvenido, Admin                  │
├────────────────────────────────────┤
│ [Universal MXI Counter]            │
│ Total: 0 MXI                       │ ← ACTUALIZADO
├────────────────────────────────────┤
│ ⚠️ ZONA DE PELIGRO                 │
│ [🔄 Reiniciar Todos los Usuarios]  │
├────────────────────────────────────┤
│ Usuarios: 7                        │
│ Activos: 0                         │ ← ACTUALIZADO
│ Total USDT: 0                      │ ← ACTUALIZADO
│ Total MXI: 0                       │ ← ACTUALIZADO
└────────────────────────────────────┘
```

---

## 🔐 Flujo de Seguridad

```
┌─────────────────────────────────────────────────────────────┐
│                    CAPAS DE SEGURIDAD                        │
└─────────────────────────────────────────────────────────────┘

CAPA 1: Autenticación
┌────────────────────────────────────┐
│ Usuario intenta acceder            │
└────────────────────────────────────┘
                │
                ▼
        ┌───────────────┐
        │ ¿Autenticado? │
        └───────────────┘
         │           │
      SÍ │           │ NO
         │           ▼
         │    [Redirect Login]
         ▼
┌────────────────────────────────────┐
│ CAPA 2: Autorización               │
└────────────────────────────────────┘
                │
                ▼
        ┌───────────────┐
        │ ¿Es Admin?    │
        │ (admin_users) │
        └───────────────┘
         │           │
      SÍ │           │ NO
         │           ▼
         │    [Acceso Denegado]
         ▼
┌────────────────────────────────────┐
│ CAPA 3: Confirmación UI            │
└────────────────────────────────────┘
                │
                ▼
        ┌───────────────┐
        │ Modal abierto │
        │ Advertencias  │
        └───────────────┘
                │
                ▼
        ┌───────────────┐
        │ Texto ==      │
        │ "RESETEAR"?   │
        └───────────────┘
         │           │
      SÍ │           │ NO
         │           ▼
         │    [Botón Deshabilitado]
         ▼
┌────────────────────────────────────┐
│ CAPA 4: Validación Backend        │
└────────────────────────────────────┘
                │
                ▼
        ┌───────────────┐
        │ Verifica      │
        │ p_admin_id    │
        │ en DB         │
        └───────────────┘
         │           │
      SÍ │           │ NO
         │           ▼
         │    [Error: No permisos]
         ▼
┌────────────────────────────────────┐
│ CAPA 5: Transacción Atómica       │
└────────────────────────────────────┘
                │
                ▼
        ┌───────────────┐
        │ BEGIN         │
        │ ...           │
        │ COMMIT        │
        └───────────────┘
         │           │
    ÉXITO│           │ ERROR
         │           ▼
         │    ┌───────────────┐
         │    │ ROLLBACK      │
         │    │ Sin cambios   │
         │    └───────────────┘
         ▼
┌────────────────────────────────────┐
│ CAPA 6: Protección de Admin       │
│ WHERE id != p_admin_id             │
└────────────────────────────────────┘
                │
                ▼
        [Reset Exitoso]
```

---

## 📊 Flujo de Datos

```
┌─────────────────────────────────────────────────────────────┐
│                    TRANSFORMACIÓN DE DATOS                   │
└─────────────────────────────────────────────────────────────┘

ANTES DEL RESET:
┌────────────────────────────────────┐
│ users                              │
├────────────────────────────────────┤
│ id: uuid-1                         │
│ mxi_balance: 1500.50               │
│ usdt_contributed: 500.00           │
│ mxi_purchased_directly: 1000.00    │
│ mxi_from_commissions: 300.50       │
│ mxi_from_challenges: 200.00        │
│ active_referrals: 5                │
│ is_active_contributor: true        │
└────────────────────────────────────┘
                │
                │ RESET
                ▼
DESPUÉS DEL RESET:
┌────────────────────────────────────┐
│ users                              │
├────────────────────────────────────┤
│ id: uuid-1                         │
│ mxi_balance: 0                     │ ← RESETEADO
│ usdt_contributed: 0                │ ← RESETEADO
│ mxi_purchased_directly: 0          │ ← RESETEADO
│ mxi_from_commissions: 0            │ ← RESETEADO
│ mxi_from_challenges: 0             │ ← RESETEADO
│ active_referrals: 0                │ ← RESETEADO
│ is_active_contributor: false       │ ← RESETEADO
└────────────────────────────────────┘

TABLAS RELACIONADAS:
┌────────────────────────────────────┐
│ commissions: 150 rows              │
│ referrals: 75 rows                 │
│ contributions: 200 rows            │
│ withdrawals: 10 rows               │
└────────────────────────────────────┘
                │
                │ DELETE
                ▼
┌────────────────────────────────────┐
│ commissions: 0 rows                │ ← LIMPIADO
│ referrals: 0 rows                  │ ← LIMPIADO
│ contributions: 0 rows              │ ← LIMPIADO
│ withdrawals: 0 rows                │ ← LIMPIADO
└────────────────────────────────────┘

MÉTRICAS:
┌────────────────────────────────────┐
│ metrics                            │
├────────────────────────────────────┤
│ total_tokens_sold: 2565897         │
│ current_phase: 2                   │
│ phase_1_tokens_sold: 1500000       │
│ phase_2_tokens_sold: 1065897       │
└────────────────────────────────────┘
                │
                │ RESET
                ▼
┌────────────────────────────────────┐
│ metrics                            │
├────────────────────────────────────┤
│ total_tokens_sold: 0               │ ← RESETEADO
│ current_phase: 1                   │ ← RESETEADO
│ phase_1_tokens_sold: 0             │ ← RESETEADO
│ phase_2_tokens_sold: 0             │ ← RESETEADO
└────────────────────────────────────┘
```

---

## ⏱️ Línea de Tiempo

```
T=0s    Usuario abre Panel Admin
        │
T=1s    Carga estadísticas
        │
T=2s    Usuario ve Zona de Peligro
        │
T=5s    Usuario hace clic en Reset
        │
T=5.1s  Modal se abre
        │
T=10s   Usuario lee advertencias
        │
T=15s   Usuario escribe "RESETEAR"
        │
T=16s   Botón se habilita
        │
T=17s   Usuario hace clic en Confirmar
        │
T=17.1s Inicia ejecución de función SQL
        │
T=17.2s Verifica permisos ✓
        │
T=17.3s Cuenta usuarios ✓
        │
T=18s   Resetea usuarios ✓
        │
T=19s   Limpia tablas ✓
        │
T=20s   Resetea métricas ✓
        │
T=20.1s Retorna resultado ✓
        │
T=20.2s Muestra Alert de éxito
        │
T=22s   Usuario hace clic en OK
        │
T=22.1s Cierra modal
        │
T=22.2s Recarga estadísticas
        │
T=23s   Panel actualizado
        │
T=24s   [PROCESO COMPLETO]
```

---

**Este diagrama de flujo proporciona una visualización completa del proceso de reset, desde la perspectiva del usuario, la base de datos, la seguridad y los datos. 🔄**
