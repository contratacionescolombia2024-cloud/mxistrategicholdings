
# Flujo Visual del Sistema de Pagos

## Diagrama de Flujo Completo

```
┌─────────────────────────────────────────────────────────────────┐
│                    INICIO - Usuario en App                       │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  PASO 1: Ingresar Monto                                          │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ • Usuario ingresa monto en USDT (3 - 500,000)            │   │
│  │ • App calcula MXI a recibir (monto / precio_fase)        │   │
│  │ • Muestra: "Recibirás: X MXI"                            │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  PASO 2: Click "Continuar al Pago"                               │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ Frontend → create-payment-intent (sin pay_currency)      │   │
│  │                                                           │   │
│  │ Request:                                                  │   │
│  │ {                                                         │   │
│  │   order_id: "MXI-timestamp-userid",                      │   │
│  │   price_amount: 100,                                      │   │
│  │   price_currency: "usd"                                   │   │
│  │ }                                                         │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  EDGE FUNCTION: create-payment-intent (Fase 1)                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ 1. Verifica API Key de NOWPayments                       │   │
│  │ 2. Autentica usuario con JWT                             │   │
│  │ 3. Valida parámetros (order_id, amount, currency)       │   │
│  │ 4. Llama a NOWPayments: GET /v1/currencies               │   │
│  │ 5. Retorna lista de criptomonedas disponibles            │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  PASO 3: Modal de Selección de Criptomoneda                      │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ • Muestra lista filtrada:                                │   │
│  │   - USDT (TRC20, ERC20, BEP20)                          │   │
│  │   - BTC, ETH, BNB, TRX                                   │   │
│  │ • Usuario selecciona una                                 │   │
│  │ • Click en "Pagar"                                       │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  PASO 4: Crear Invoice                                           │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ Frontend → create-payment-intent (con pay_currency)      │   │
│  │                                                           │   │
│  │ Request:                                                  │   │
│  │ {                                                         │   │
│  │   order_id: "MXI-timestamp-userid",                      │   │
│  │   price_amount: 100,                                      │   │
│  │   price_currency: "usd",                                  │   │
│  │   pay_currency: "usdttrc20"                              │   │
│  │ }                                                         │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  EDGE FUNCTION: create-payment-intent (Fase 2)                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ 1. Obtiene datos de fase actual (precio, fase)          │   │
│  │ 2. Calcula MXI a recibir                                 │   │
│  │ 3. Crea registro en transaction_history (pending)       │   │
│  │ 4. Llama a NOWPayments: POST /v1/invoice                │   │
│  │    {                                                      │   │
│  │      price_amount: 100,                                   │   │
│  │      price_currency: "usd",                               │   │
│  │      pay_currency: "usdttrc20",                          │   │
│  │      ipn_callback_url: "webhook_url",                    │   │
│  │      order_id: "MXI-...",                                │   │
│  │      order_description: "Compra de X MXI - Fase Y"      │   │
│  │    }                                                      │   │
│  │ 5. Actualiza transaction_history (waiting)              │   │
│  │ 6. Crea registro en nowpayments_orders                  │   │
│  │ 7. Retorna invoice_url                                   │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  PASO 5: Abrir Página de Pago                                    │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ • App abre invoice_url en navegador                      │   │
│  │ • Usuario ve página de NOWPayments                       │   │
│  │ • Muestra dirección de pago y monto                      │   │
│  │ • Usuario envía criptomoneda                             │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  PASO 6: Polling de Estado (Frontend)                            │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ • App consulta nowpayments_orders cada 5 segundos       │   │
│  │ • Muestra estado actual: waiting → confirming → finished│   │
│  │ • Continúa hasta que estado sea final                   │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  PASO 7: NOWPayments Detecta Pago                                │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ • NOWPayments confirma transacción en blockchain        │   │
│  │ • Envía webhook a: /functions/v1/nowpayments-webhook    │   │
│  │ • Incluye firma HMAC para seguridad                     │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  EDGE FUNCTION: nowpayments-webhook                               │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ 1. Verifica firma HMAC del webhook                       │   │
│  │ 2. Registra webhook en nowpayments_webhook_logs         │   │
│  │ 3. Busca orden en nowpayments_orders                    │   │
│  │ 4. Actualiza estado de orden y transacción              │   │
│  │                                                           │   │
│  │ Si status = "finished" o "confirmed":                    │   │
│  │   5. Valida moneda de pago                               │   │
│  │   6. Valida monto (permite 5% de variación)             │   │
│  │   7. Obtiene datos del usuario                           │   │
│  │   8. Actualiza balances:                                 │   │
│  │      • mxi_balance += mxi_amount                         │   │
│  │      • mxi_purchased_directly += mxi_amount             │   │
│  │      • usdt_contributed += usdt_amount                   │   │
│  │      • yield_rate_per_minute += (mxi * 0.00005 / 60)   │   │
│  │   9. Crea registro en contributions                      │   │
│  │  10. Actualiza metrics (total_tokens_sold, etc.)        │   │
│  │  11. Procesa comisiones de referidos (5%, 2%, 1%)      │   │
│  │  12. Marca orden como confirmed                         │   │
│  │  13. Marca transacción como finished                    │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│  PASO 8: Notificación al Usuario                                 │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ • Polling detecta cambio de estado                       │   │
│  │ • App muestra alerta: "¡Pago Confirmado!"               │   │
│  │ • Muestra MXI recibido                                   │   │
│  │ • Actualiza balance en pantalla                          │   │
│  │ • Detiene polling                                        │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    FIN - Pago Completado                          │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ ✅ MXI acreditado en balance del usuario                 │   │
│  │ ✅ Comisiones distribuidas a referidores                 │   │
│  │ ✅ Métricas actualizadas                                 │   │
│  │ ✅ Rendimiento (yield) activado                          │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

## Estados de la Transacción

```
pending → waiting → confirming → finished ✅
                              ↓
                           failed ❌
                              ↓
                           expired ⏰
                              ↓
                          cancelled 🚫
```

## Tablas de Base de Datos Involucradas

### 1. transaction_history
```
Registra cada intento de pago
- order_id: Identificador único
- status: pending → waiting → finished
- mxi_amount: MXI a recibir
- usdt_amount: USDT pagado
- metadata: Información adicional
```

### 2. nowpayments_orders
```
Almacena órdenes de NOWPayments
- order_id: Mismo que transaction_history
- payment_url: URL de pago
- status: Estado actual
- pay_currency: Cripto seleccionada
- expires_at: Fecha de expiración
```

### 3. nowpayments_webhook_logs
```
Registra todos los webhooks recibidos
- payment_id: ID de NOWPayments
- order_id: Referencia a orden
- payload: Datos completos del webhook
- processed: Si fue procesado exitosamente
```

### 4. users
```
Balance y estadísticas del usuario
- mxi_balance: Balance total
- mxi_purchased_directly: MXI comprado
- usdt_contributed: USDT invertido
- yield_rate_per_minute: Tasa de rendimiento
```

### 5. contributions
```
Historial de contribuciones
- user_id: Usuario
- usdt_amount: Monto en USDT
- mxi_amount: MXI recibido
- status: completed
```

### 6. commissions
```
Comisiones de referidos
- user_id: Referidor
- from_user_id: Usuario que compró
- level: 1, 2, o 3
- amount: MXI de comisión
- percentage: 5%, 2%, o 1%
```

### 7. metrics
```
Métricas globales del sistema
- total_tokens_sold: Total MXI vendido
- total_usdt_contributed: Total USDT recibido
- phase_X_tokens_sold: Tokens por fase
- current_phase: Fase actual
- current_price_usdt: Precio actual
```

## Comisiones de Referidos

```
Usuario Compra 100 MXI
         │
         ├─► Nivel 1 (Referidor Directo)
         │   └─► 5 MXI (5%)
         │
         ├─► Nivel 2 (Referidor del Referidor)
         │   └─► 2 MXI (2%)
         │
         └─► Nivel 3 (Referidor del Nivel 2)
             └─► 1 MXI (1%)

Total Comisiones: 8 MXI (8%)
Usuario Recibe: 100 MXI
```

## Rendimiento (Yield)

```
Por cada MXI en balance:
- Tasa: 0.005% por hora
- Cálculo: mxi_amount * 0.00005 / 60 por minuto
- Se acumula automáticamente
- Se puede reclamar en cualquier momento
```

## Seguridad

```
┌─────────────────────────────────────┐
│  Capas de Seguridad                 │
├─────────────────────────────────────┤
│  1. JWT Authentication (Frontend)   │
│  2. HMAC Signature (Webhook)        │
│  3. Amount Validation (±5%)         │
│  4. Currency Validation             │
│  5. Double-Processing Prevention    │
│  6. Service Role Key (Webhook)      │
└─────────────────────────────────────┘
```

---

**Nota:** Este flujo asume que todas las variables de entorno están correctamente configuradas y que la cuenta de NOWPayments está activa y verificada.
